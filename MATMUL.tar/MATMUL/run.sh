
#script to run different versions of matrix multiplication code
echo MMM Python code
python matmul.py
echo MMM Java code
java mm_java

echo "MMM GCC compiler (O1)"
./matmul_O1
echo "MMM GCC compiler (O2)"
./matmul_O2
echo "MMM GCC compiler (O3)"
./matmul_O3

echo "MMM ICC compiler (O0)"
./matmul_icc_O0
echo "MMM ICC compiler (O1)"
./matmul_icc_O1
echo "MMM ICC compiler (O2)"
./matmul_icc_O2
echo "MMM ICC compiler (O3)"
./matmul_icc_O3

echo "MMM (cilk 16 cores) ICC compiler (O1)"
./matmul_cilk_O1
echo "MMM (cilk 16 cores) ICC compiler (O2)"
./matmul_cilk_O2
echo "MMM (cilk 16 cores) ICC compiler (O3)"
./matmul_cilk_O3


echo "MMM (cilk 16 cores) tiling ICC compiler (O1)"
./matmul_cilk_tile_O1
echo "MMM (cilk 16 cores) tiling ICC compiler (O2)"
./matmul_cilk_tile_O2
echo "MMM (cilk 16 cores) tiling ICC compiler (O3)"
./matmul_cilk_tile_O3

echo "MMM cilk divide and conquer (O1)"
./matmul_cilk_dc_O1
echo "MMM cilk divide and conquer (O2)"
./matmul_cilk_dc_O2
echo "MMM cilk divide and conquer (O3)"
./matmul_cilk_dc_O3

echo "MMM cilk + dc + xHost"
 ./matmul_cilk_dc_O3xHost

echo "MMM cilk + dc + xHost + AVX"
./matmul_cilk_dc_O3xH_AVX


echo "MMM MKL BLAS"
./matmul_mkl

