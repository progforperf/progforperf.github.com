#include <stdio.h>
#include <cilk/cilk.h>

int whee() {
    return 10;
}

int blah() {
    return 5;
}

int main(int argc, char **argv) {
    int x, y;

    x = cilk_spawn whee();
    y = cilk_spawn blah();
    cilk_sync;

    printf("Got %d %d, expecting %d %d\n", x, y, 10, 5);
    return 0;
}
