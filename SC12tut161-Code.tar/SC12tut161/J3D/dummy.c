void dummy_( double *a , double *b)
{

}

void dummy( double *a , double *b)
{

}

      

