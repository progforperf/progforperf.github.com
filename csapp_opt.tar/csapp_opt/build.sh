  gcc -g -Wall -O1 -I.  -msse3 -fno-inline -fno-optimize-sibling-calls -lrt -mfpmath=sse -m64 -DSUM -DFLOAT -o fpbench benchmark.c combine.c vec.c  libcsapp64.a
[dsudheer@gordon-ln4 csapp_opt]$ ls
benchmark.c  benchmark-log.txt  clock.h  combine.c  combine.h  cpe.h  csapp.h  fcyc.h  fpbench  include  isbench  libcsapp64.a  lsquare.h  vec.c  vec.h
[dsudheer@gordon-ln4 csapp_opt]$  gcc -g -Wall -O1 -I.  -msse3 -fno-inline -fno-optimize-sibling-calls -lrt -mfpmath=sse -m64 -DSUM -DINT -o isbench benchmark.c combine.c vec.c  libcsapp64.a

