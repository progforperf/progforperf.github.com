/* taken from slide 50 MIT 6.162 lecture 1 Fall 2012 */
// MATMUL parallel divide-and-conquer

#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include <assert.h>
#include <cilk/cilk.h>
typedef unsigned long long uint64_t;
//#define n 4096
#define n 1024

const int DIM = n*n;
double A[DIM];
double B[DIM];
double C[DIM];
double D[DIM];
float tdiff (struct timeval *start, struct timeval *end)
{
return (end->tv_sec - start->tv_sec) + 1e-6* (end->tv_usec - start->tv_usec);
}

/*
void mmdac (double *C, double *A, double *B, int size)
{ 
if (size <= 1)
{ *C += *A * *B; 
}
else
{
int s11 = 0;
int s12 = size/2;
int s21 = (size/2)*n;
int s22 = (size/2)*(n+1);

cilk_spawn mmdac(C+s11,A+s11, B+s11,size/2);
cilk_spawn mmdac(C+s12, A+s11, B+s12, size/2);
cilk_spawn mmdac(C+s21, A+s21, B+s11,size/2);
mmdac(C+s22, A+s21, B+s12, size/2);
cilk_sync;

cilk_spawn mmdac(C+s11, A+s12, B+s21, size/2);
cilk_spawn mmdac(C+s12, A+s12, B+s22, size/2);
cilk_spawn mmdac(C+s21, A+s22, B+s21, size/2);	
mmdac(C+s22,A+s22, B+s22, size/2); 
cilk_sync;
}
}
*/
// coarsed the recursion to avoid function call overhead.
void mmdac (double *C, double *A, double *B, int size)
{
int cblock=8;
if (size <= cblock)
{ 
  for (int i=0;i<size;i++)
  for (int j=0;j<size;j++)
  for (int k=0;k<size;k++)
   C[i*n+j] += A[i*n+k] * B[k*n+j];
}
else
{
int s11 = 0;
int s12 = size/2;
int s21 = (size/2)*n;
int s22 = (size/2)*(n+1);

cilk_spawn mmdac(C+s11,A+s11, B+s11,size/2);
cilk_spawn mmdac(C+s12, A+s11, B+s12, size/2);
cilk_spawn mmdac(C+s21, A+s21, B+s11,size/2);
mmdac(C+s22, A+s21, B+s12, size/2);
cilk_sync;

cilk_spawn mmdac(C+s11, A+s12, B+s21, size/2);
cilk_spawn mmdac(C+s12, A+s12, B+s22, size/2);
cilk_spawn mmdac(C+s21, A+s22, B+s21, size/2);
mmdac(C+s22,A+s22, B+s22, size/2);
cilk_sync;
}
}





int main(int argc, const char *argv[])
{
for (int i=0; i<DIM; ++i)
{
//  for (int j=0; j<n; ++j)
//{
	A[i] = (double)rand() / (double)RAND_MAX;
	B[i] = (double)rand() / (double)RAND_MAX;
	C[i] = 0;
	D[i] = 0;
//}
}

struct timeval start, end;
gettimeofday( &start, NULL);

mmdac(C, A, B, n);
gettimeofday(&end, NULL);
printf("%0.6f\n", tdiff(&start, &end));

for (int i=0; i<n; ++i)
{
for ( int j=0; j<n; ++j)
{ for ( int k=0; k<n; ++k)
{
D[i*n+j] += A[i*n+k] * B[k*n+j];
}
}
}

for (int i=0; i<DIM; ++i)
{
   if(C[i] != D[i]) { printf("MATMUL INVALID\n");}
}



float numf = (double)rand() / (double)RAND_MAX;
int num = (int) numf % (n);
printf("numf+%f, num=%d\n", numf,num);
printf("printing a random element from C: (to avoid dead code elimination)%lf, num:%d\n", C[num], num);
return 0;
}


