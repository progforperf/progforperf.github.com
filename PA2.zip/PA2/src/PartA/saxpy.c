/*
 * SAXPY
 */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#include <tmmintrin.h>

#include "utils.h"
#include "rdtsc.h"

#define N 1024

// Procedure saxpy: Serial code (do not need to modify)

void saxpy(float a, float const * x, float const * y, float * z) {
  int i;
  for(i = 0; i < N; i++) {
    z[i] = a*x[i] + y[i];
  }

}



// Procedure vec_saxpy: vector code (implement)

void vec_saxpy(float a, float const * x, float const * y, float * z) {

  // Substitute from here..
  printf("Implement vec_saxpy\n");
  abort();
  // ...to here

}




/*
 * Do not need to modify from here on
 */

#define RUNS     400
#define CYCLES_REQUIRED 1e7

void verify(float a, float const * x, float const * y, float const * z)
{
  int i;
  double err;
  float * temp = (float *) _mm_malloc(sizeof(float)*N, 16);
  setzero(temp, N, 1);

  for(i = 0; i < N; i++) {
      temp[i] = a*x[i] + y[i];
      err = fabs(z[i] - temp[i]);
      if(err > 1E-5)
        {
          printf("Error at z[%d]\n", i);
        }
  }

  _mm_free(temp);

}

void test_vec_saxpy(float a, float const * x, float const * y, float * z)
{
  tsc_counter start, end;
  double cycles = 0.;
  size_t num_runs = RUNS;
  int i;


  //Cache warm-up
  // RDTSCP reads ts register guaranteeing that the execution of all the code
  // we wanted to measure is completed. This way we avoid including the
  // execution of a CPUID in between. The last CPUID guarantees no other
  // instruction can be scheduled before it (and so also before RDTSCP)

  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);
  CPUID(); RDTSC(start); CPUID(); RDTSC(end);

  while(1) {
      CPUID(); RDTSC(start);
      for (i = 0; i < num_runs; ++i) {
          vec_saxpy(a, x, y, z);
      }
      CPUID(); RDTSC(end);

      cycles = (double)(COUNTER_DIFF(end, start));

      if(cycles >= CYCLES_REQUIRED) break;

      num_runs *= 2;

  }

  CPUID(); RDTSC(start);
  for (i = 0; i < num_runs; ++i) {
      vec_saxpy(a, x, y, z);
  }
  CPUID(); RDTSC(end);

  cycles = (double)(COUNTER_DIFF(end, start))/num_runs;

  printf("Test vec_saxpy  - Performance [flops/cycle]: %f\n", 2.*N/cycles);

#ifdef VERIFY
  verify(a, x, y, z);
#endif

}

int main()
{
  float a = 2.5;
  float * x = (float *) _mm_malloc(sizeof(float)*N, 16);
  float * y = (float *) _mm_malloc(sizeof(float)*N, 16);
  float * z = (float *) _mm_malloc(sizeof(float)*N, 16);

  setrandom(x, N, 1);
  setrandom(y, N, 1);

  test_vec_saxpy(a, x, y, z);

  return 0;
}
