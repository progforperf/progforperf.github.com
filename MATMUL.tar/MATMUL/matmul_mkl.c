#include <stdio.h>
#include <stdlib.h>
#include "mkl_cblas.h"
#include <sys/time.h>
#include <assert.h>

#include <float.h>  // For: DBL_EPSILON
typedef unsigned long long uint64_t;
//#define n 4096
#define n 1024
const int DIM=n*n;
double A[DIM];
double B[DIM];
double C[DIM];
double D[DIM];
float tdiff (struct timeval *start, struct timeval *end)
{
return (end->tv_sec - start->tv_sec) + 1e-6* (end->tv_usec - start->tv_usec);
}

int main(int argc, const char *argv[])
{
for (int i=0; i<DIM; ++i)
{
 A[i] = (double)rand() / (double)RAND_MAX;
 B[i] = (double)rand() / (double)RAND_MAX;
 C[i] = 0;
 D[i] = 0;
}

struct timeval start, end;
gettimeofday( &start, NULL);

cblas_dgemm( CblasRowMajor,CblasNoTrans,CblasNoTrans, n,n,n, 1.0, A,n, B,n, 1.0, C,n );


gettimeofday(&end, NULL);
printf("%0.6f\n", tdiff(&start, &end));

for (int i=0; i<n; ++i)
{
for ( int j=0; j<n; ++j)
{ for ( int k=0; k<n; ++k)
{
D[i*n+j] += A[i*n+k] * B[k*n+j];
}
}
}

for (int i=0; i<DIM; ++i)
{
   if(abs(C[i] - D[i]) > 3.0*DBL_EPSILON*n ) { printf("MATMUL INVALID\n"); return 0;}
}

int num = rand() % (n);
printf("printing a random element from C: (to avoid dead code elimination)%lf, %d\n", C[num], num);
return 0;
}




