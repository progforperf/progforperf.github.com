#include <ia32intrin.h>
#include <stdlib.h>
#include <stdio.h>

void t1(float* A, float* B)
{
	unsigned long long start_c, end_c, diff_c;
	start_c = _rdtsc();
	for (int nl = 0; nl < 1000000; nl++){
	  #pragma vector always
		for (int i = 0; i < 1024; i+=2)
		  A[i+1] = A[i] + B[i];
		B[0]++;
	}
	
	end_c=_rdtsc();
	diff_c = end_c - start_c;
	float giga_cycle = diff_c / 1000000000.0;
	float ret = 0;
	for (int i = 0; i < 1024; i++)
		ret += A[i];
	printf("It took %f giga cycles and the result is: %f", giga_cycle, ret);
}

int main(){
	float* A = (float*) _mm_malloc(1024*sizeof(float), 16);
	float* B = (float*) _mm_malloc(1024*sizeof(float), 16);
	for (int i = 0; i < 1024; i++){
		A[i] = 1. / (i+1);
		B[i] = 2. / (i+1);
	}
	t1(A,B);
	printf("\n");
}
