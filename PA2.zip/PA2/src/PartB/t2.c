#include <ia32intrin.h>
#include <stdlib.h>
#include <stdio.h>

#pragma auto_inline(off)
void t2(float* __restrict__ A, float* __restrict__ B)
{
	unsigned long long start_c, end_c, diff_c;
	start_c = _rdtsc();
	//#pragma novector
	for (int nl = 0; nl < 10000000; nl++){

	    for (int i = 0; i < 1280 - 5; i+=5){
	    		A[i] = B[i] * A[i];
			A[i + 1] = B[i] * A[i + 1];
			A[i + 2] = B[i] * A[i + 2];
			A[i + 3] = B[i] * A[i + 3];
			A[i + 4] = B[i] * A[i + 4];
		}
		A[0]++;

		
	}
	
	end_c=_rdtsc();
	diff_c = end_c - start_c;
	float giga_cycle = diff_c / 1000000000.0;
	float ret = 0.;
	#pragma novector
	for (int i = 0; i < 1280; i++)
		ret += A[i];
	printf("It took %f giga cycles and the result is: %f", giga_cycle, ret);
}

int main(){
	float* A = (float*) _mm_malloc(1280*sizeof(float), 16);
	float* B = (float*) _mm_malloc(1280*sizeof(float), 16);
	#pragma novector
	for (int i = 0; i < 1280; i++){
		A[i] = 1./(i+10000.);
		B[i] = 1./(i+10000.);
	}
	t2(A, B);
	printf("\n");
}
