#!/bin/sh
MATMUL_DIR=`pwd`

cat > serial.sbatch <<EOF
#!/bin/bash
#SBATCH -J matmul	 # Job Name
#SBATCH  -p serial
#SBATCH -o $JOB_NAME.o$JOB_ID	 # Name of the output file (eg. matmul.oJobID)
#SBATCH -N 1 -n 1 	 # Requests 1 core
#SBATCH -t 00:30:00	 # Run time (hh:mm:ss) - 0.5 hours
##SBATCH --mail-user=email
##SBATCH --mail-type=END
cd $MATMUL_DIR
export MKLROOT= /opt/apps/intel/13/composer_xe_2013.1.117/mkl
hostname > timing-$2.out
$1 >> timing-$2.out
exit 0;
EOF
