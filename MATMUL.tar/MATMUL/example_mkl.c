#include <stdio.h>
#include <stdlib.h>
#include "mkl_cblas.h"

int main (int argc, char ** argv)
{
  if(argc !=3)
   printf("need 2 numbers\n");
  else {
	float x = atof(argv[1]);
	float y = atof(argv[2]);
	cblas_saxpy(1,1.0, &x,1, &y,1);
   	printf("Sum is : %f\n", y);
}
}
