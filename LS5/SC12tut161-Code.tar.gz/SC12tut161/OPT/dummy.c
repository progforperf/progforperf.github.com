
void dummy(double *m) {}

void dummy_(double *m) {}
