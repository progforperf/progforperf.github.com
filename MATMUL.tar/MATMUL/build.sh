
#script to build different versions of matrix multiplication code.

 gcc matmul.c -o matmul_O0 -std=c99
 gcc -O1 matmul.c -o matmul_O1 -std=c99
 gcc -O2 matmul.c -o matmul_O2 -std=c99
 gcc -O3 matmul.c -o matmul_O3 -std=c99


 icc -O0 matmul.c -o matmul_icc_O0 -std=c99
 icc -O1 matmul.c -o matmul_icc_O1 -std=c99
 icc -O2 matmul.c -o matmul_icc_O2 -std=c99
# icc -O2 -std=c99 matmul.c -o matmul_icc_O2 -no-vec -vec-report2 -opt-report2
 icc -O3 matmul.c -o matmul_icc_O3 -std=c99
# icc -O3 -std=c99 matmul.c -o matmul_icc_O3 -no-vec -vec-report2 -opt-report2

 icc -O1 matmul_cilk.c -o matmul_cilk_O1 -std=c99
 icc -O2 matmul_cilk.c -o matmul_cilk_O2 -std=c99
 icc -O3 matmul_cilk.c -o matmul_cilk_O3 -std=c99

 icc -O1 matmul_cilk_tile.c -o matmul_cilk_tile_O1 -std=c99
 icc -O2 matmul_cilk_tile.c -o matmul_cilk_tile_O2 -std=c99
 icc -O3 matmul_cilk_tile.c -o matmul_cilk_tile_O3 -std=c99

 icc -O1 matmul_cilk_dc.c -o matmul_cilk_dc_O1 -std=c99 
 icc -O2 matmul_cilk_dc.c -o matmul_cilk_dc_O2 -std=c99 
 icc -O3 matmul_cilk_dc.c -o matmul_cilk_dc_O3 -std=c99 

 icc -O3 -xHost matmul_cilk_dc.c -o matmul_cilk_dc_O3xHost -std=c99
 icc -O3 -xHost -axAVX matmul_cilk_dc.c -o matmul_cilk_dc_O3xH_AVX -std=c99

 icc -O3 -o matmul_mkl  matmul_mkl.c -std=c99 -mkl


